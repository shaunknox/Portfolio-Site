$(function() {
 
    var petName = prompt('What is your kitten\'s name?');
    var petWeight = prompt('How much does your kitten weigh?');
    var petWeight = parseInt(petWeight);
    var petHappiness = prompt('How happy do you think your kitten is on a scale of 1-10?');
    var petHappiness = parseInt(petHappiness);
    var pet_info = {
        name: petName,
        weight: petWeight,
        happiness: petHappiness,
    }
    
    checkAndUpdatePetInfoInHtml();
  
    $('.treat-button').click(clickedTreatButton);
    $('.play-button').click(clickedPlayButton);
    $('.exercise-button').click(clickedExerciseButton);
    $('.reset-button').click(clickedExerciseButton);

    function clickedTreatButton() {
        // Increase pet happiness
        pet_info.happiness +=1
        // Increase pet weight
        pet_info.weight +=2
        checkAndUpdatePetInfoInHtml();
    }
    
    function clickedPlayButton() {
        // Increase pet happiness
        pet_info.happiness +=1
        // Decrease pet weight
        pet_info.weight -=1
        checkAndUpdatePetInfoInHtml();
    }
    
    function clickedExerciseButton() {
        // Decrease pet happiness
        pet_info.happiness -=2
        // Decrease pet weight
        pet_info.weight -=1
        checkAndUpdatePetInfoInHtml();
    }
  
    function checkAndUpdatePetInfoInHtml() {
        checkWeightAndHappinessBeforeUpdating();  
        updatePetInfoInHtml();
    }
    
    function checkWeightAndHappinessBeforeUpdating() {
        if (pet_info.weight < 0) {
            pet_info.weight === 0
            checkAndUpdatePetInfoInHtml();
        } else if (pet_info.happiness < 0) {
            pet_info.happiness === 0
            checkAndUpdatePetInfoInHtml();
        }
    }
    
    // Updates HTML with the current values in pet_info object
    function updatePetInfoInHtml() {
        $('.name').text(pet_info.name);
        $('.weight').text(pet_info.weight);
        $('.happiness').text(pet_info.happiness);
        $('.reset').text(pet_info.reset)
    }
})